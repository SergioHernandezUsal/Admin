#!/usr/bin/perl
use strict;
use warnings;
use DBI;
use File::Copy;
use File::Path qw(make_path);
use File::Find;
use Linux::usermod;
use Passwd::Unix;
use Quota;

die "Debe ejecutarse como root\n" if $> != 0;

my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica;host=localhost",
    "admineco",
    "admineco123",
    { RaiseError => 1, mysql_enable_utf8 => 1 }
);

sub login_valido {
    my ($login) = @_;
    return defined $login && $login =~ /^[a-z0-9._-]{3,20}$/;
}

sub rol_valido {
    my ($rol) = @_;
    return defined $rol && $rol =~ /^(ciudadano|tecnico)$/;
}

sub hash_valido {
    my ($hash) = @_;
    return defined $hash && $hash =~ /^\$y\$/;
}

sub aplicar_cuota {
    my ($login, $uid, $rol) = @_;

    my ($soft, $hard) = ($rol eq 'tecnico')
        ? (102400, 122880)
        : (40960,  51200);

    my $dev = Quota::getqcarg('/');

    unless ($dev) {
        print "[ERROR CUOTA] No se pudo obtener dispositivo de cuota para /\n";
        return;
    }

    my $res = Quota::setqlim($dev, $uid, $soft, $hard, 0, 0);

    if (defined $res && $res == 0) {
        print "[CUOTA] Cuota aplicada a $login: soft=$soft KB hard=$hard KB\n";
    } else {
        my $err = Quota::strerr() || $! || "error desconocido";
        print "[ERROR CUOTA] No se pudo aplicar cuota a $login: res="
            . (defined $res ? $res : "undef")
            . " error=$err dev=$dev uid=$uid\n";
    }
}

my $sth = $dbh->prepare("
    SELECT id, login, rol, pass_tmp
    FROM usuarios
    WHERE estado = 'confirmado'
");

$sth->execute();

while (my $u = $sth->fetchrow_hashref) {

    unless (
        login_valido($u->{login}) &&
        rol_valido($u->{rol})     &&
        hash_valido($u->{pass_tmp})
    ) {
        print "[ERROR] Datos inválidos para usuario id=$u->{id}\n";
        next;
    }

    if (getpwnam($u->{login})) {

        my $uid_existente = (getpwnam($u->{login}))[2];

        print "[AVISO] Usuario $u->{login} ya existe en el sistema\n";

        aplicar_cuota($u->{login}, $uid_existente, $u->{rol});

        $dbh->do(
            "UPDATE usuarios SET estado='activo', pass_tmp=NULL WHERE id=?",
            undef,
            $u->{id}
        );

        next;
    }

    my $grupo = ($u->{rol} eq 'tecnico') ? 'tecnicos' : 'ciudadanos';
    my $gid   = (getgrnam($grupo))[2];

    unless (defined $gid) {
        print "[ERROR] No existe el grupo $grupo\n";
        next;
    }

    my $home = "/home/$u->{login}";

    Linux::usermod->add(
        $u->{login},
        '!',
        '',
        $gid,
        '',
        $home,
        '/bin/bash'
    );

    my $uid = (getpwnam($u->{login}))[2];

    unless (defined $uid) {
        print "[ERROR] No se pudo obtener UID de $u->{login}\n";
        next;
    }

    my $pu      = Passwd::Unix->new();
    my @usuario = $pu->user($u->{login});

    unless (@usuario) {
        print "[ERROR] No se pudo leer usuario $u->{login} desde passwd/shadow\n";
        next;
    }

    $pu->user(
        $u->{login},
        $u->{pass_tmp},
        $usuario[1],
        $usuario[2],
        $usuario[3],
        $usuario[4],
        $usuario[5]
    );

    make_path($home, { mode => 0755 });

    find(sub {

        my $src = $File::Find::name;
        return if -l $src;

        (my $dst = $src) =~ s|^/etc/skel|$home|;

        if (-d $src) {
            make_path($dst, { mode => 0755 });
            chown $uid, $gid, $dst;
        } elsif (-f $src) {
            copy($src, $dst);
            chown $uid, $gid, $dst;


            if ($dst =~ m|public_html/index\.html$|) {
                if (open(my $fh, "<:encoding(UTF-8)", $dst)) {
                    my @lineas = <$fh>;
                    close($fh);

                    for (@lineas) {

                        s/\{\{USUARIO\}\}/$u->{login}/g;
                    }

                    if (open(my $out, ">:encoding(UTF-8)", $dst)) {
                        print $out @lineas;
                        close($out);
                    }
                }
            }

        }

    }, '/etc/skel');

    chown $uid, $gid, $home;

    my $pubhtml  = "$home/public_html";
    my $informes = "$home/informes_sostenibilidad";

    make_path($pubhtml,  { mode => 0755 });
    make_path($informes, { mode => 0755 });

    chown $uid, $gid, $pubhtml;
    chown $uid, $gid, $informes;

    chmod 0711, $home;
    chmod 0755, $pubhtml;
    chmod 0755, $informes;

    aplicar_cuota($u->{login}, $uid, $u->{rol});

    $dbh->do(
        "UPDATE usuarios SET estado='activo', pass_tmp=NULL WHERE id=?",
        undef,
        $u->{id}
    );

    print "[ACTIVACIÓN] Usuario $u->{login} activado (UID $uid)\n";
}

$dbh->disconnect;