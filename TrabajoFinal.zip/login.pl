#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use CGI::Session;
use IPC::Open2;

my $cgi = CGI->new;
my $usuario  = $cgi->param('usuario')  || '';
my $password = $cgi->param('password') || '';
sub registrar_log {

    my ($tipo, $usuario) = @_;

    my $ip = $ENV{REMOTE_ADDR} || 'desconocida';

    if (open(my $log, '>>', '/var/log/ecosalmantica_accesos.log')) {

        print $log
            "[" . scalar(localtime) . "] " .
            "$tipo usuario=$usuario ip=$ip\n";

        close($log);
    }
}

sub html_error {
    my ($mensaje) = @_;
    print $cgi->header(-type => 'text/html', -charset => 'UTF-8');
    print "<h1>Error: $mensaje</h1><p><a href='/login/'>Volver</a></p>";
    exit;
}

html_error("Faltan datos")     if ($usuario eq '' || $password eq '');
html_error("Usuario no válido") if ($usuario !~ /^[a-zA-Z0-9._-]+$/);

sub es_valida {
    my ($u, $p) = @_;
    local $ENV{PWAUTH_WITHW} = 1;
    my $pid = open2(my $out, my $in, '/usr/sbin/pwauth');
    print $in "$u\n$p\n";
    close($in);
    close($out);
    waitpid($pid, 0);
    return ($? == 0);
}

unless (es_valida($usuario, $password)) {

    registrar_log("WEB_FAIL", $usuario);

    html_error("Usuario o contraseña incorrectos");
}


my $es_tecnico = 0;
my @pw = getpwnam($usuario);
if (@pw) {
    my $gid_usuario = $pw[3];
    my @grupo = getgrnam("tecnicos");
    if (@grupo) {
        my $gid_tecnicos = $grupo[2];
        my $miembros     = $grupo[3] || '';
        $es_tecnico = 1 if ($gid_usuario == $gid_tecnicos || $miembros =~ /\b$usuario\b/);
    }
}


my $session = CGI::Session->new("driver:File", undef, {Directory => '/var/lib/cgi-sessions'});
$session->param('usuario',    $usuario);
$session->param('es_tecnico', $es_tecnico);
$session->expire('+1h');

my $cookie = $cgi->cookie(
    -name     => 'CGISESSID',
    -value    => $session->id,
    -httponly => 1,
    -secure   => 1
);
registrar_log("WEB_OK", $usuario);
print $cgi->redirect(
    -uri    => '/cgi-bin/portal.pl',
    -cookie => $cookie
);