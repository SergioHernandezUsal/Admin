#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use CGI::Session;
use IPC::Open2;
use DBI;
binmode(STDOUT, ":encoding(UTF-8)");

my $cgi     = CGI->new;
my $session = CGI::Session->new("driver:File", $cgi, {Directory => '/var/lib/cgi-sessions'});

unless ($session && $session->param('usuario')) {
    print $cgi->redirect('/login/');
    exit;
}

my $usuario     = $session->param('usuario');
my $nombre      = $cgi->param('nombre')      || '';
my $email       = $cgi->param('email')       || '';
my $pass_actual = $cgi->param('pass_actual') || '';

sub redirigir {
    my ($msg, $tipo) = @_;
    use URI::Escape;
    my $msg_enc = uri_escape($msg);
    print $cgi->redirect("/cgi-bin/perfil.pl?msg=$msg_enc&tipo=$tipo");
    exit;
}

sub verificar_password {
    my ($u, $p) = @_;
    local $ENV{PWAUTH_WITHW} = 1;
    my $pid = open2(my $out, my $in, '/usr/sbin/pwauth');
    print $in "$u\n$p\n";
    close($in);
    close($out);
    waitpid($pid, 0);
    return ($? == 0);
}

unless (verificar_password($usuario, $pass_actual)) {
    redirigir("Contraseña actual incorrecta.", "err");
}

unless ($nombre =~ /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{2,100}$/) {
    redirigir("Nombre no válido.", "err");
}

unless ($email =~ /^[^@\s]+@[^@\s]+\.[^@\s]+$/) {
    redirigir("Email no válido.", "err");
}

my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica;host=localhost",
    "admineco", "admineco123",
    { RaiseError => 1, mysql_enable_utf8 => 1 }
);

my $check = $dbh->prepare("SELECT id FROM usuarios WHERE email = ? AND login != ?");
$check->execute($email, $usuario);
if ($check->fetchrow_array) {
    redirigir("Ese email ya está en uso.", "err");
}

$dbh->prepare("UPDATE usuarios SET nombre = ?, email = ? WHERE login = ?")
   ->execute($nombre, $email, $usuario);

$dbh->disconnect;
redirigir("Datos actualizados correctamente.", "ok");