#!/usr/bin/perl

use strict;
use warnings;

use DBI;
use Archive::Tar;
use File::Find;
use POSIX qw(strftime);

my $fecha = strftime("%Y-%m-%d_%H-%M", localtime);

my $backup_dir = "/backups";

mkdir $backup_dir unless -d $backup_dir;


my $sql_file = "$backup_dir/bd_$fecha.sql";

my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica",
    "root",
    "",
    { RaiseError => 1, AutoCommit => 1 }
);

open(my $sql, ">", $sql_file)
    or die "No se pudo crear SQL\n";

my $tables =
    $dbh->selectcol_arrayref("SHOW TABLES");

foreach my $table (@$tables) {

    my $create =
        $dbh->selectrow_array(
            "SHOW CREATE TABLE $table"
        );

    print $sql
        "DROP TABLE IF EXISTS $table;\n";
    print $sql "$create;\n\n";

    my $rows =
        $dbh->selectall_arrayref(
            "SELECT * FROM $table",
            { Slice => {} }
        );

    foreach my $row (@$rows) {

        my @cols = keys %$row;

        my @vals = map {
            defined $row->{$_}
                ? $dbh->quote($row->{$_})
                : "NULL"
        } @cols;

        print $sql
            "INSERT INTO $table ("
            . join(",", @cols)
            . ") VALUES ("
            . join(",", @vals)
            . ");\n";
    }

    print $sql "\n\n";
}

close($sql);


my $tar = Archive::Tar->new;

$tar->add_files(
    $sql_file
);

sub add_dir {

    my ($dir) = @_;

    find(
        sub {
            return unless -f $_;
            $tar->add_files($File::Find::name);
        },
        $dir
    );
}

add_dir("/home");
add_dir("/etc");
add_dir("/var/www");
add_dir("/var/log");
add_dir("/root");
add_dir("/monitorizacion");

$tar->write(
    "$backup_dir/sistema_$fecha.tar.gz",
    COMPRESS_GZIP
);

unlink($sql_file);


find(
    sub {

        return unless -f $_;

        my $dias =
            (time - (stat($_))[9]) / 86400;

        if ($dias > 7) {
            unlink($_);
        }
    },
    $backup_dir
);

print "Backup completado correctamente\n";