#!/usr/bin/perl

use strict;
use warnings;

use Email::MIME;
use Email::Sender::Simple qw(sendmail);
use Email::Sender::Transport::SMTP qw();
use Try::Tiny;
use LWP::UserAgent;

my $fecha = `date +%Y-%m-%d`;
chomp($fecha);



my $url = "http://sergio:S69FXE5zICOpO2\@localhost:3000/render/d/sebdxtk/informe?orgId=1&from=now-24h&to=now&width=1400&height=900&kiosk";

my $ua = LWP::UserAgent->new;

my $response = $ua->get($url);

die "Error descargando imagen\n"
    unless $response->is_success;

open(my $fh, '>', '/tmp/informe.png')
    or die "No se pudo guardar la imagen\n";

binmode($fh);

print $fh $response->decoded_content(charset => 'none');

close($fh);

open($fh, '<', '/tmp/informe.png') or die "No se pudo abrir la imagen";
binmode($fh);

my $imagen = do { local $/; <$fh> };

close($fh);


my $message = Email::MIME->create(

    header_str => [
        From    => 'grafana@ecosalmantica.local',
        To      => 'sergio@localhost',
        Subject => "Informe diario Smart City - $fecha",
    ],

    parts => [

        Email::MIME->create(
                attributes => {
                        content_type => "text/plain",
                        charset      => "UTF-8",
                        encoding     => "quoted-printable",
                },

                body_str => "Adjunto se encuentra el informe diario de monitorizacion.\n\nPanel Grafana:\nhttp://158.179.216.143:3000/d/sebdxtk/informe",
        ),

        Email::MIME->create(
            attributes => {
                filename     => "informe.png",
                content_type => "image/png",
                encoding     => "base64",
                disposition  => "attachment",
            },

            body => $imagen,
        ),
    ],
);


try {

    sendmail(
        $message,
        {
            from => 'grafana@ecosalmantica.local',

            transport => Email::Sender::Transport::SMTP->new({
                host => 'localhost',
                port => 25,
            }),
        }
    );

    print "Informe enviado correctamente\n";

}
catch {

    warn "Error enviando correo: $_";

};