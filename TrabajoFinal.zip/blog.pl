#!/usr/bin/perl

use strict;
use warnings;
use utf8;
use CGI qw(:standard);
use CGI::Session;
use CGI::Carp qw(fatalsToBrowser);

binmode(STDOUT, ":encoding(UTF-8)");

my $RUTA = "/blogs_ciudadanos";

my $cgi = CGI->new;

my $session = CGI::Session->load(
    undef,
    $cgi,
    { Directory => '/var/lib/cgi-sessions' }
);

my $usuario = $session->param('usuario');

sub esc {

    my ($txt) = @_;

    $txt //= "";

    $txt =~ s/&/&amp;/g;
    $txt =~ s/</&lt;/g;
    $txt =~ s/>/&gt;/g;
    $txt =~ s/\"/&quot;/g;
    $txt =~ s/'/&#39;/g;

    return $txt;
}

if ($usuario && $cgi->param('mensaje')) {

    my $mensaje = $cgi->param('mensaje');

    if ($mensaje ne "") {

        opendir(my $dir, $RUTA);

        my @posts = grep {

            /^post_\d+\.txt$/

        } readdir($dir);

        closedir($dir);

        my $id = scalar(@posts) + 1;

        my $archivo = "$RUTA/post_$id.txt";

        open(my $fh, ">:encoding(UTF-8)", $archivo);

        print $fh "AUTOR:$usuario\n";

        print $fh "FECHA:" . localtime() . "\n";

        print $fh "LIKES:0\n";

        print $fh "LIKEDBY:\n";

        print $fh "CONTENIDO:\n";

        print $fh "$mensaje\n";

        close($fh);
    }

    print $cgi->redirect('/blog/');

    exit;
}

if ($usuario && $cgi->param('like')) {

    my $id = $cgi->param('like');

    my $archivo = "$RUTA/post_$id.txt";

    if (-f $archivo) {

        open(my $fh, "<:encoding(UTF-8)", $archivo);

        my @lineas = <$fh>;

        close($fh);

        my $likes = 0;

        my @likedby;

        foreach my $l (@lineas){

            if ($l =~ /^LIKES:(\d+)/){

                $likes = $1;

            }

            if ($l =~ /^LIKEDBY:(.*)/){

                @likedby = split(/,/, $1);
            }
        }

        if (grep { $_ eq $usuario } @likedby){

            @likedby = grep { $_ ne $usuario } @likedby;

            $likes--;

        } else {

            push(@likedby, $usuario);

            $likes++;
        }

        for (@lineas){

            $_ = "LIKES:$likes\n" if /^LIKES:/;

            $_ = "LIKEDBY:" . join(',', @likedby) . "\n" if /^LIKEDBY:/;
        }

        unless (grep { /^LIKEDBY:/ } @lineas){

            push(@lineas, "LIKEDBY:" . join(',', @likedby) . "\n");
        }

        open(my $out, ">:encoding(UTF-8)", $archivo);

        print $out @lineas;

        close($out);
    }

    print $cgi->redirect('/blog/');

    exit;
}

print $cgi->header(
    -type => 'text/html',
    -charset => 'UTF-8'
);

print <<'HTML';

<!DOCTYPE html>

<html lang="es">

<head>

<meta charset="UTF-8">

<title>Foro Ciudadano</title>

<style>

body{

    font-family:Arial;

    background:#f0f2f5;

    margin:40px;
}

h1{

    color:darkgreen;
}

.post{

    background:white;

    padding:20px;

    border-radius:10px;

    margin-top:20px;

    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

.usuario{

    color:#0077cc;

    font-weight:bold;

    font-size:20px;
}

.fecha{

    color:gray;

    font-size:14px;

    margin-bottom:10px;
}

.likes{

    margin-top:15px;

    color:#cc3300;

    font-weight:bold;
}

textarea{

    width:100%;

    height:120px;
}

button{

    padding:10px 16px;

    border:none;

    border-radius:5px;

    cursor:pointer;

    color:white;

    font-weight:bold;

    background:#0077cc;
}

.publicar{

    background:#28a745;
}

.like{

    background:#cc3300;
}

</style>

</head>

<body>

<h1>Foro Ciudadano</h1>

HTML

if ($usuario){

print "

<div class='post'>

<h2>Nueva propuesta</h2>

<form method='POST'>

<textarea name='mensaje' required></textarea>

<br><br>

<button type='submit' class='publicar'>

Publicar

</button>

</form>

</div>

";

} else {

print "

<div class='post'>

Debe iniciar sesión para publicar y dar likes.

</div>

";
}

opendir(my $dir, $RUTA);

my @posts = sort grep {

    /^post_\d+\.txt$/

} readdir($dir);

closedir($dir);

@posts = reverse @posts;

foreach my $archivo (@posts){

    open(my $fh, "<:encoding(UTF-8)", "$RUTA/$archivo");

    my @lineas = <$fh>;

    close($fh);

    my ($autor,$fecha,$likes,$contenido);
        my @likedby;

    foreach my $l (@lineas){

        chomp($l);

        if ($l =~ /^AUTOR:(.*)/){

            $autor = esc($1);

        } elsif ($l =~ /^FECHA:(.*)/){

            $fecha = esc($1);

        } elsif ($l =~ /^LIKES:(\d+)/){

            $likes = $1;
        } elsif ($l =~ /^LIKEDBY:(.*)/){

            @likedby = split(/,/, $1);

        } elsif ($l !~ /^(AUTOR|FECHA|LIKES|CONTENIDO):/){

            $contenido .= esc($l) . "<br>";
        }
    }

    my ($id) = $archivo =~ /post_(\d+)/;

    print "

    <div class='post'>

    <div class='usuario'>$autor</div>

    <div class='fecha'>$fecha</div>

    <div>$contenido</div>

    <div class='likes'>

    $likes likes

    </div>

    ";

    if ($usuario){

    print "

    <form method='POST'>

    <input type='hidden' name='like' value='$id'>

    <button class='like'>

    👍 Like

    </button>

    </form>

    ";
    }

    print "</div>";
}

print <<'HTML';

<div style="margin-top:20px;">

<a href="/cgi-bin/portal.pl">

<button>

Volver al portal

</button>

</a>

</div>

</body>

</html>

HTML