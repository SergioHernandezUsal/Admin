#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use CGI::Session;
use DBI;
binmode(STDOUT, ":encoding(UTF-8)");

my $cgi     = CGI->new;
my $session = CGI::Session->new("driver:File", $cgi, {Directory => '/var/lib/cgi-sessions'});

unless ($session && $session->param('usuario')) {
    print $cgi->redirect('/login/');
    exit;
}

my $usuario = $session->param('usuario');
my $msg     = $cgi->param('msg')  || '';
my $tipo    = $cgi->param('tipo') || '';

my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica;host=localhost",
    "admineco", "admineco123",
    { RaiseError => 1, mysql_enable_utf8 => 1 }
);

my $sth = $dbh->prepare("SELECT nombre, email FROM usuarios WHERE login = ?");
$sth->execute($usuario);
my $datos = $sth->fetchrow_hashref;
$dbh->disconnect;

my $clase    = ($tipo eq 'ok') ? 'ok' : 'err';
my $bloque_msg = $msg ? "<p class='$clase'>$msg</p>" : '';

print $cgi->header(-type => 'text/html', -charset => 'UTF-8');
print <<"HTML";
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mi Perfil - EcoSalmántica</title>
<link rel="stylesheet" href="/css/estilos.css">
</head>
<body>
<h1>ECOSALMÁNTICA SMART CITY</h1>
<p>
    Usuario: <b>$usuario</b> |
    <a href="/cgi-bin/portal.pl">Volver al portal</a> |
    <a href="/cgi-bin/logout.pl">Cerrar sesión</a>
</p>

$bloque_msg

<div class="bloque">
<h2>Modificar datos personales</h2>
<p>El login no puede modificarse.</p>
<form method="POST" action="/cgi-bin/cambiar_datos.pl">
<label>Nombre completo:</label>
<input type="text" name="nombre" value="$datos->{nombre}" required>
<label>Email:</label>
<input type="email" name="email" value="$datos->{email}" required>
<label>Contraseña actual (obligatoria para confirmar):</label>
<input type="password" name="pass_actual" required>
<button type="submit">Guardar cambios</button>
</form>
</div>

<div class="bloque">
<h2>Cambiar contraseña</h2>
<form method="POST" action="/cgi-bin/cambiar_password.pl">
<label>Contraseña actual:</label>
<input type="password" name="pass_actual" required>
<label>Nueva contraseña:</label>
<input type="password" name="pass_nueva" required>
<label>Repetir nueva contraseña:</label>
<input type="password" name="pass_nueva2" required>
<small>Mínimo 8 caracteres, mayúscula, minúscula y número.</small>
<button type="submit">Cambiar contraseña</button>
</form>
</div>

<div class="bloque">
<h2>Darse de baja</h2>
<p>Esta acción eliminará tu cuenta. No se puede deshacer.</p>
<form method="POST" action="/cgi-bin/baja.pl">
<label>Contraseña actual (para confirmar):</label>
<input type="password" name="pass_actual" required>
<button type="submit" class="rojo">Darme de baja</button>
</form>
</div>

</body>
</html>
HTML