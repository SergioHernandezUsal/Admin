#!/usr/bin/perl

use strict;
use warnings;
use utf8;
use CGI;
use DBI;
use IPC::Open2;
use Encode;

binmode(STDOUT, ":encoding(UTF-8)");

my $cgi = CGI->new;

if ($cgi->request_method eq 'POST') {

    my $titulo = $cgi->param('titulo') || '';
    my $texto  = $cgi->param('descripcion') || '';

    print $cgi->header(
        -type    => 'text/html',
        -charset => 'UTF-8'
    );

    if ($titulo eq '' || $texto eq '') {

        print "<h1>Error</h1>";
        print "<p>Faltan datos.</p>";

        exit;
    }

    my $prompt = qq{
Clasifica la siguiente incidencia municipal.

SOLO puedes usar:

Categorias:
- Alumbrado
- Limpieza
- Seguridad
- Trafico
- Agua
- Parques
- Mantenimiento

Urgencia:
- Baja
- Media
- Alta

Departamentos:
- Servicios Técnicos
- Policía
- Medio Ambiente
- Movilidad Urbana

Devuelve EXACTAMENTE este formato:

Categoria: ...
Urgencia: ...
Departamento: ...

Incidencia:
"$texto"
};

    $ENV{'HOME'} = '/opt/ollama-web';

my $pid = open2(
    my $out,
    my $in,
    '/usr/local/bin/ollama',
    'run',
    'llama3.2'
);

print $in $prompt;

close($in);

my $respuesta = do {
    local $/;
    decode('UTF-8', <$out>);
};

waitpid($pid, 0);

my ($categoria) =
    $respuesta =~ /Categoria:\s*([^\n\r]+)/i;

my ($urgencia) =
    $respuesta =~ /Urgencia:\s*([^\n\r]+)/i;

my ($departamento) =
    $respuesta =~ /Departamento:\s*([^\n\r]+)/i;

    $categoria    ||= 'Sin clasificar';
    $urgencia     ||= 'Media';
    $departamento ||= 'Servicios Técnicos';

    my $dbh = DBI->connect(
        "DBI:mysql:database=ecosalmantica;host=localhost",
        "admineco",
        "admineco123",
        { RaiseError => 1, mysql_enable_utf8 => 1 }
    );

    $dbh->do(

        "INSERT INTO incidencias
        (titulo, descripcion, categoria, urgencia, departamento)
        VALUES (?, ?, ?, ?, ?)",

        undef,

        $titulo,
        $texto,
        $categoria,
        $urgencia,
        $departamento
    );

    $dbh->disconnect;

    print <<"HTML";

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">

<title>Incidencia registrada</title>

<style>

body {

    margin: 0;
    padding: 40px;
    background: #f1f5f9;
    font-family: Arial, sans-serif;
}

.contenedor {

    max-width: 900px;
    margin: auto;
}

.tarjeta {

    background: white;
    border-radius: 20px;
    padding: 40px;
    box-shadow: 0 10px 35px rgba(0,0,0,0.08);
}

h1 {

    color: #16a34a;
    margin-top: 0;
}

.campo {

    margin-bottom: 20px;
    line-height: 1.6;
}

.badge {

    display: inline-block;
    padding: 8px 14px;
    border-radius: 999px;
    font-weight: bold;
    color: white;
}

.categoria {
    background: #2563eb;
}

.urgencia {
    background: #dc2626;
}

.departamento {
    background: #7c3aed;
}

.volver {

    display: inline-block;
    margin-top: 30px;
    background: #2563eb;
    color: white;
    padding: 14px 22px;
    border-radius: 12px;
    text-decoration: none;
    font-weight: bold;
}

.volver:hover {

    background: #1d4ed8;
}

</style>

</head>

<body>

<div class="contenedor">

<div class="tarjeta">

<h1>Incidencia registrada correctamente</h1>

<div class="campo">
<b>Título:</b><br>
$titulo
</div>

<div class="campo">
<b>Descripción:</b><br>
$texto
</div>

<div class="campo">
<b>Categoría IA:</b><br><br>
<span class="badge categoria">
$categoria
</span>
</div>

<div class="campo">
<b>Urgencia IA:</b><br><br>
<span class="badge urgencia">
$urgencia
</span>
</div>

<div class="campo">
<b>Departamento IA:</b><br><br>
<span class="badge departamento">
$departamento
</span>
</div>

<a class="volver" href="/cgi-bin/incidencia.pl">
Nueva incidencia
</a>

</div>
</div>

</body>
</html>

HTML

    exit;
}

print $cgi->header(
    -type    => 'text/html',
    -charset => 'UTF-8'
);

print <<"HTML";

<!DOCTYPE html>
<html lang="es">

<head>

<meta charset="UTF-8">

<title>Nueva incidencia municipal</title>

<style>

body {

    margin: 0;
    padding: 40px;
    background: #f1f5f9;
    font-family: Arial, sans-serif;
    color: #1e293b;
}

.contenedor {

    max-width: 900px;
    margin: auto;
}

.tarjeta {

    background: white;
    border-radius: 20px;
    padding: 40px;
    box-shadow: 0 10px 35px rgba(0,0,0,0.08);
}

h1 {

    margin-top: 0;
    font-size: 34px;
    color: #0f172a;
}

.subtitulo {

    color: #64748b;
    margin-bottom: 35px;
}

label {

    display: block;
    margin-bottom: 10px;
    font-weight: bold;
}

input,
textarea {

    width: 100%;
    padding: 14px;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    font-size: 15px;
    box-sizing: border-box;
    margin-bottom: 25px;
}

input:focus,
textarea:focus {

    outline: none;
    border-color: #2563eb;
    box-shadow: 0 0 0 4px rgba(37,99,235,0.12);
}

textarea {

    min-height: 180px;
    resize: vertical;
}

button {

    background: #2563eb;
    color: white;
    border: none;
    padding: 14px 26px;
    border-radius: 12px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}

button:hover {

    background: #1d4ed8;
}

.info {

    margin-top: 30px;
    background: #eff6ff;
    border-left: 5px solid #2563eb;
    padding: 20px;
    border-radius: 12px;
    color: #1e3a8a;
}

</style>

</head>

<body>

<div class="contenedor">

<div class="tarjeta">

<h1>Nueva incidencia municipal</h1>

<p class="subtitulo">
Las incidencias serán clasificadas automáticamente mediante IA municipal.
</p>

<form method="POST">

<label>Título</label>

<input
    type="text"
    name="titulo"
    required
>

<label>Descripción de la incidencia</label>

<textarea
    name="descripcion"
    required
></textarea>

<button type="submit">
Enviar incidencia
</button>

</form>

<div class="info">

<b>Sistema Inteligente Ecosalmantica</b><br><br>

La incidencia será clasificada automáticamente por IA:
<ul>
<li>Categoría</li>
<li>Urgencia</li>
<li>Departamento responsable</li>
</ul>

</div>

<div style="margin-top:20px;">

<a href="/cgi-bin/portal.pl">

<button>

Volver al portal

</button>

</a>

</div>

</div>
</div>

</body>
</html>
HTML