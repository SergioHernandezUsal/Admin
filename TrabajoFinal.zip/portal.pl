#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use CGI::Session;
use IO::Socket::INET;

binmode(STDOUT, ":encoding(UTF-8)");

my $cgi     = CGI->new;
my $session = CGI::Session->new("driver:File", $cgi, {Directory => '/var/lib/cgi-sessions'});

unless ($session && $session->param('usuario')) {
    print $cgi->redirect('/login/');
    exit;
}

my $usuario    = $session->param('usuario');
my $es_tecnico = $session->param('es_tecnico') || 0;

sub check_service {
    my ($host, $port) = @_;
    my $socket = IO::Socket::INET->new(
        PeerAddr => $host,
        PeerPort => $port,
        Proto    => 'tcp',
        Timeout  => 1
    );
    if ($socket) {
        close($socket);
        return '<b style="color:white; background:#008000; padding:4px 10px; border-radius:4px; font-size:0.8em;">OPERATIVO</b>';
    } else {
        return '<b style="color:white; background:#cc0000; padding:4px 10px; border-radius:4px; font-size:0.8em;">CAÍDO</b>';
    }
}

my $s_web  = check_service('localhost', 80);
my $s_ssl  = check_service('localhost', 443);
my $s_ssh  = check_service('localhost', 22);
my $s_sql  = check_service('localhost', 3306);

print $cgi->header(-type => 'text/html', -charset => 'UTF-8');

print <<"HTML";
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Portal EcoSalmántica</title>
    <style>
        body { font-family: Arial, sans-serif; background:#f0f2f5; margin:40px; color: #333; }
        h1 { color:darkgreen; margin-bottom: 20px; text-transform: uppercase; }
        .user-bar { margin-bottom: 20px; font-size: 0.9em; }
        .logout { float:right; color:#cc0000; text-decoration: none; font-weight: bold; }

        nav { background:#333; padding:15px; border-radius:8px; margin-bottom: 25px; }
        nav a { color:white; text-decoration:none; margin-right:20px; font-weight:bold; }

        .bloque { background:white; padding:40px; border-radius:12px; box-shadow:0 4px 15px rgba(0,0,0,0.05); }

        h2 { font-size: 1.4em; margin-top: 0; margin-bottom: 20px; }


        ul.servicios { list-style: none; padding-left: 20px; line-height: 35px; margin-bottom: 40px; }
        ul.servicios li::before { content: "•"; color: #0077cc; display: inline-block; width: 1em; margin-left: -1em; }
        ul.servicios a { color:#0077cc; text-decoration:none; font-weight: bold; }
        ul.servicios a:hover { text-decoration:underline; }


        .monitor-box { margin-top: 30px; padding-top: 30px; border-top: 1px solid #eee; }
        .monitor-title { font-size: 1.1em; border-left: 4px solid #1b5e20; padding-left: 15px; margin-bottom: 25px; color: #37474f; font-weight: bold; }
        .status-row { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #f9f9f9; }
        .status-row:last-of-type { border-bottom: none; }
    </style>
</head>
<body>

    <h1>ECOSALMÁNTICA SMART CITY</h1>

    <div class="user-bar">
        Sesión iniciada como: <b>$usuario</b>
        <a class="logout" href="/cgi-bin/logout.pl">Cerrar sesión</a>
    </div>

    <nav>
        <a href="/cgi-bin/portal.pl">Inicio</a>
        <a href="/~$usuario/">Web Personal</a>
HTML

print '<a href="/manuales/">Manuales Técnicos</a>' if $es_tecnico;

print <<"HTML";
    </nav>

    <div class="bloque">
        <h2>Servicios Disponibles</h2>

        <ul class="servicios">
            <li><a href="/ecorreo">Correo municipal</a></li>
            <li><a href="/cgi-bin/blog.pl">Blog ciudadano</a></li>
            <li><a href="/~$usuario/">Web personal</a></li>
            <li><a href="/cgi-bin/perfil.pl">Mi perfil</a></li>
            <li><a href="/cgi-bin/incidencia.pl">Nueva incidencia municipal IA</a></li>
HTML

if ($es_tecnico) {
    print '<li><a href="/manuales/">Gestión de manuales técnicos</a></li>';
}

print <<"HTML";
        </ul>

        <div class="monitor-box">
            <div class="monitor-title">Monitorización del Sistema</div>

            <div class="status-row">
                <span>Servidor Web (Apache)</span>
                $s_web
            </div>

            <div class="status-row">
                <span>Cifrado de Seguridad (SSL/TLS)</span>
                $s_ssl
            </div>

            <div class="status-row">
                <span>Acceso Seguro (SSH/SFTP)</span>
                $s_ssh
            </div>

            <div class="status-row">
                <span>Base de Datos (MariaDB)</span>
                $s_sql
            </div>

            <p style="font-size: 0.8em; color: #888; margin-top: 30px; font-style: italic;">

            </p>
        </div>
    </div>

</body>
</html>
HTML