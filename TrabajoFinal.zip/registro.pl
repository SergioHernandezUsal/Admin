#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use DBI;
use MIME::Lite;

my $cgi = CGI->new;

binmode(STDOUT, ":encoding(UTF-8)");

my $nombre   = $cgi->param('nombre')   || '';
my $login    = $cgi->param('login')    || '';
my $email    = $cgi->param('email')    || '';
my $password = $cgi->param('password') || '';
my $rol      = $cgi->param('rol')      || '';

sub error {

    my ($m) = @_;

    print $cgi->header(
        -type    => 'text/html',
        -charset => 'UTF-8'
    );

    print "<html><body>";
    print "<h3>Error: $m</h3>";
    print "<a href='javascript:history.back()'>Volver</a>";
    print "</body></html>";

    exit;
}



error("Login inválido")
    unless $login =~ /^[a-z0-9._-]{3,20}$/;

error("Email inválido")
    unless $email =~ /^[^@\s]+\@[^@\s]+\.[^@\s]+$/;

error("Password débil")
    unless $password =~ /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

error("Rol inválido")
    unless $rol =~ /^(ciudadano|tecnico)$/;



my $salt = '$y$j9T$' . join(
    '',
    map { ('a'..'z','A'..'Z','0'..'9')[rand 62] } 1..16
);

my $hash = crypt($password, $salt);



my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica;host=localhost",
    "admineco",
    "admineco123",
    {
        RaiseError        => 1,
        mysql_enable_utf8 => 1
    }
);



my $check = $dbh->prepare(
    "SELECT id, estado
     FROM usuarios
     WHERE login = ?
     LIMIT 1"
);

$check->execute($login);

my ($uid_existente, $estado_existente) = $check->fetchrow_array;

if ($uid_existente) {


    if ($estado_existente ne 'pendiente') {

        $dbh->disconnect;

        error("El login ya existe.");
    }


    $dbh->do(
        "DELETE FROM tokens_verificacion
         WHERE usuario_id = ?",
        undef,
        $uid_existente
    );

    $dbh->do(
        "DELETE FROM usuarios
         WHERE id = ?",
        undef,
        $uid_existente
    );
}



$check = $dbh->prepare(
    "SELECT id, estado
     FROM usuarios
     WHERE email = ?
     LIMIT 1"
);

$check->execute($email);

my ($uid_email, $estado_email) = $check->fetchrow_array;

if ($uid_email) {


    if ($estado_email ne 'pendiente') {

        $dbh->disconnect;

        error("El correo ya está registrado.");
    }


    $dbh->do(
        "DELETE FROM tokens_verificacion
         WHERE usuario_id = ?",
        undef,
        $uid_email
    );

    $dbh->do(
        "DELETE FROM usuarios
         WHERE id = ?",
        undef,
        $uid_email
    );
}



my $ins = $dbh->prepare(
    "INSERT INTO usuarios
     (login, email, nombre, rol, estado, pass_tmp)
     VALUES (?, ?, ?, ?, 'pendiente', ?)"
);

$ins->execute(
    $login,
    $email,
    $nombre,
    $rol,
    $hash
);

my $uid = $dbh->{mysql_insertid};



my $codigo = 10000 + int(rand(90000));



$dbh->do(
    "INSERT INTO tokens_verificacion
     (usuario_id, token, expira)
     VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 DAY))",
    undef,
    $uid,
    $codigo
);



eval {

    my $msg = MIME::Lite->new(
        From    => 'carloscuadrado0606@gmail.com',
        To      => $email,
        Subject => 'Verificación de cuenta - EcoSalmantica',
        Data    => <<"MAIL"
Hola $nombre,

Tu código de verificación es:

$codigo

Este código caduca en 24 horas.

EcoSalmantica
MAIL
    );

    $msg->send;
};

if ($@) {

    warn "Error enviando correo: $@";

    $dbh->disconnect;

    error("No se pudo enviar el correo de verificación.");
}

$dbh->disconnect;



print $cgi->redirect('/registro/confirmacion.html');