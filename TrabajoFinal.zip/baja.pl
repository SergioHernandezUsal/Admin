#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use CGI::Session;
use IPC::Open2;
use DBI;
use URI::Escape;


binmode(STDOUT, ":encoding(UTF-8)");

my $cgi = CGI->new;


my $session = CGI::Session->new("driver:File", $cgi, {Directory => '/var/lib/cgi-sessions'});


unless ($session && $session->param('usuario')) {
    print $cgi->redirect('/login/');
    exit;
}

my $usuario     = $session->param('usuario');
my $pass_actual = $cgi->param('pass_actual') || '';


sub verificar_password {
    my ($u, $p) = @_;
    return 0 if $p eq '';

    local $ENV{PWAUTH_WITHW} = 1;
    my $pid = open2(my $out, my $in, '/usr/sbin/pwauth');
    print $in "$u\n$p\n";
    close($in);
    close($out);
    waitpid($pid, 0);
    return ($? == 0);
}


unless (verificar_password($usuario, $pass_actual)) {
    my $msg = uri_escape("La contraseña de confirmación es incorrecta.");
    print $cgi->redirect("perfil.pl?msg=$msg&tipo=err");
    exit;
}


my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica;host=localhost",
    "admineco", "admineco123",
    { RaiseError => 1, mysql_enable_utf8 => 1 }
);


eval {
    $dbh->do("UPDATE usuarios SET estado = 'baja', fecha_baja = NOW() WHERE login = ?", undef, $usuario);
};

if ($@) {

    my $error_db = uri_escape("Error en la base de datos al procesar la baja.");
    print $cgi->redirect("perfil.pl?msg=$error_db&tipo=err");
    $dbh->disconnect;
    exit;
}

$dbh->disconnect;


$session->delete();
$session->flush();


my $cookie = $cgi->cookie(
    -name    => 'CGISESSID',
    -value   => '',
    -expires => '-1d',
    -path    => '/'
);


print $cgi->redirect(
    -uri    => '/',
    -cookie => $cookie
);

exit;