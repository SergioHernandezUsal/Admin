#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use CGI::Session;
use IPC::Open2;
use DBI;
binmode(STDOUT, ":encoding(UTF-8)");

my $cgi     = CGI->new;
my $session = CGI::Session->new("driver:File", $cgi, {Directory => '/var/lib/cgi-sessions'});

unless ($session && $session->param('usuario')) {
    print $cgi->redirect('/login/');
    exit;
}

my $usuario     = $session->param('usuario');
my $pass_actual = $cgi->param('pass_actual') || '';
my $pass_nueva  = $cgi->param('pass_nueva')  || '';
my $pass_nueva2 = $cgi->param('pass_nueva2') || '';

sub redirigir {
    my ($msg, $tipo) = @_;
    use URI::Escape;
    my $msg_enc = uri_escape($msg);
    print $cgi->redirect("/cgi-bin/perfil.pl?msg=$msg_enc&tipo=$tipo");
    exit;
}

sub verificar_password {
    my ($u, $p) = @_;
    local $ENV{PWAUTH_WITHW} = 1;
    my $pid = open2(my $out, my $in, '/usr/sbin/pwauth');
    print $in "$u\n$p\n";
    close($in);
    close($out);
    waitpid($pid, 0);
    return ($? == 0);
}

unless (verificar_password($usuario, $pass_actual)) {
    redirigir("Contraseña actual incorrecta.", "err");
}

unless ($pass_nueva eq $pass_nueva2) {
    redirigir("Las nuevas contraseñas no coinciden.", "err");
}

unless ($pass_nueva =~ /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/) {
    redirigir("La nueva contraseña es demasiado débil.", "err");
}

my $salt = '$y$j9T$' . join('', map { ('a'..'z','A'..'Z','0'..'9')[rand 62] } 1..16);
my $hash = crypt($pass_nueva, $salt);

my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica;host=localhost",
    "admineco", "admineco123",
    { RaiseError => 1, mysql_enable_utf8 => 1 }
);


$dbh->prepare("DELETE FROM cambios_password WHERE login = ?")
   ->execute($usuario);


$dbh->prepare("INSERT INTO cambios_password (login, hash_nuevo) VALUES (?, ?)")
   ->execute($usuario, $hash);

$dbh->disconnect;
redirigir("Contraseña actualizada. Se aplicará en menos de 1 minuto.", "ok");