#!/usr/bin/perl
use strict;
use warnings;
use DBI;
use File::Path qw(remove_tree);
use Linux::usermod;
use Quota;

die "Debe ejecutarse como root\n" if $> != 0;

my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica;host=localhost",
    "admineco",
    "admineco123",
    { RaiseError => 1, mysql_enable_utf8 => 1 }
);

sub login_valido {
    my ($login) = @_;
    return defined $login && $login =~ /^[a-z0-9._-]{3,20}$/;
}

sub limpiar_cuota {
    my ($login, $uid) = @_;

    my $dev = Quota::getqcarg('/');

    unless ($dev) {
        print "[ERROR CUOTA] No se pudo obtener dispositivo de cuota para baja de $login\n";
        return;
    }

    my $res = Quota::setqlim($dev, $uid, 0, 0, 0, 0);

    if (defined $res && $res == 0) {
        print "[CUOTA] Cuota eliminada para $login\n";
    } else {
        my $err = Quota::strerr() || $! || "error desconocido";
        print "[ERROR CUOTA] No se pudo eliminar cuota de $login: res="
            . (defined $res ? $res : "undef")
            . " error=$err dev=$dev uid=$uid\n";
    }
}

my $sth = $dbh->prepare("
    SELECT id, login, email, nombre, rol, fecha_registro
    FROM usuarios
    WHERE estado = 'baja'
");

$sth->execute();

while (my $b = $sth->fetchrow_hashref) {

    unless (login_valido($b->{login})) {
        print "[ERROR] Login inválido en baja: $b->{login}\n";
        next;
    }


    my $archivo_historico = "/var/log/ecosalmantica_historico.log";

    if (open(my $fh, '>>', $archivo_historico)) {
        my $fecha_baja = scalar localtime;
        print $fh "FECHA_BAJA: $fecha_baja | ID: $b->{id} | LOGIN: $b->{login} | EMAIL: $b->{email} | NOMBRE: $b->{nombre} | ROL: $b->{rol} | REGISTRO: $b->{fecha_registro}\n";
        close($fh);
        print "[BAJA] Datos de $b->{login} guardados en $archivo_historico\n";
    } else {
        print "[ERROR] No se pudo escribir en el histórico para $b->{login}\n";
    }


    my $user;

    eval {
        $user = Linux::usermod->new($b->{login});
    };

    if ($user) {

        my @pw       = getpwnam($b->{login});
        my $uid_baja = $pw[2];
        my $home     = $pw[7] || "/home/$b->{login}";

        if (defined $uid_baja) {
            limpiar_cuota($b->{login}, $uid_baja);
        }

        Linux::usermod->del($b->{login});

        if (defined $home && $home =~ /^\/home\/[a-z0-9._-]{3,20}$/) {
            remove_tree($home) if -d $home;
            print "[BAJA] Usuario $b->{login} eliminado del sistema\n";
        } else {
            print "[ERROR] Home inseguro, no se borra: $home\n";
        }

    } else {
        print "[AVISO] Usuario $b->{login} no existía en el sistema\n";
    }


    $dbh->do(
        "DELETE FROM tokens_verificacion WHERE usuario_id = ?",
        undef,
        $b->{id}
    );

    $dbh->do(
        "DELETE FROM usuarios WHERE id = ?",
        undef,
        $b->{id}
    );

    print "[BAJA] Usuario $b->{login} borrado definitivamente de la base de datos\n";
}

$dbh->disconnect;