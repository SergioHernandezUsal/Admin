#!/usr/bin/perl

use strict;
use warnings;
use utf8;
use CGI qw(:standard);
use CGI::Carp qw(fatalsToBrowser);
use CGI::Session;
use File::Basename;

binmode(STDOUT, ":encoding(UTF-8)");

my $RUTA = "/manuales_smartcity";

my $LOG = "/var/log/manuales.log";

my $MAX_SIZE = 2 * 1024 * 1024;

$CGI::POST_MAX = $MAX_SIZE;

my $cgi = CGI->new;

my $session = CGI::Session->load(
    undef,
    $cgi,
    { Directory => '/var/lib/cgi-sessions' }
);

my $usuario = $session->param('usuario');

my $es_tecnico = $session->param('es_tecnico');

if (!$usuario) {

    print $cgi->redirect('/login/');

    exit;
}

if (!$es_tecnico) {

    print $cgi->header(
        -type => 'text/html',
        -charset => 'UTF-8'
    );

    print "<h1>Acceso denegado</h1>";

    exit;
}

sub escribir_log {

    my ($accion) = @_;

    open(my $log, ">>", $LOG);

    my $fecha = localtime();

    print $log "[$fecha] $usuario - $accion\n";

    close($log);
}

my $mensaje  = "";

my $es_error = 0;

sub nombre_valido {

    my ($nombre) = @_;

    return 0 unless defined $nombre;

    return 0 if $nombre =~ m{/};

    return 0 if $nombre =~ m{\.\.};

    return 0 unless $nombre =~ /^[a-zA-Z0-9_-]+\.txt$/;

    return 1;
}

sub esc {

    my ($txt) = @_;

    $txt //= "";

    $txt =~ s/&/&amp;/g;

    $txt =~ s/</&lt;/g;

    $txt =~ s/>/&gt;/g;

    $txt =~ s/"/&quot;/g;

    $txt =~ s/'/&#39;/g;

    return $txt;
}

if ($cgi->param('borrar')) {

    my $archivo = $cgi->param('borrar');

    if (nombre_valido($archivo)) {

        unlink("$RUTA/$archivo");

        escribir_log("BORRADO $archivo");

        print $cgi->redirect('/manuales/');

        exit;
    }
}

if ($cgi->param('guardar')) {

    my $archivo   = $cgi->param('archivo');

    my $contenido = $cgi->param('contenido');

    if (nombre_valido($archivo)) {

        if (open(my $fh, ">:encoding(UTF-8)", "$RUTA/$archivo")) {

            print $fh $contenido;

            close($fh);

            escribir_log("MODIFICADO $archivo");

            print $cgi->redirect('/manuales/');

            exit;

        } else {

            $mensaje  = "Error guardando archivo";

            $es_error = 1;
        }
    }
}

my $filehandle = $cgi->upload('manual');

if ($filehandle) {

    my $filename = basename($cgi->param('manual'));

    $filename =~ s/\s+/_/g;

    my $mime = $cgi->uploadInfo($filehandle)->{'Content-Type'};

    if ($mime ne 'text/plain') {

        $mensaje = "Solo archivos TXT reales";
        escribir_log("SUBIDA BLOQUEADA MIME $filename");

        $es_error = 1;

    } elsif (!nombre_valido($filename)) {

        $mensaje  = "Solo archivos .txt";
        escribir_log("SUBIDA BLOQUEADA NOMBRE $filename");

        $es_error = 1;

    } elsif (-e "$RUTA/$filename") {

        $mensaje  = "El archivo ya existe";
        escribir_log("SUBIDA BLOQUEADA EXISTE $filename");

        $es_error = 1;

    } else {

        if (open(my $out, ">:raw", "$RUTA/$filename")) {

            while (read($filehandle, my $buffer, 4096)) {

                print $out $buffer;
            }

            close($out);

            escribir_log("SUBIDO $filename");

            print $cgi->redirect('/manuales/');

            exit;

        } else {

            $mensaje  = "Error subiendo archivo";

            $es_error = 1;
        }
    }
}

opendir(my $dir, $RUTA);

my @archivos = sort grep {

    !/^\./ &&
    $_ ne "index.pl" &&
    /\.txt$/i

} readdir($dir);

closedir($dir);

my ($editar_archivo, $editar_contenido) = ("", "");

if ($cgi->param('editar')) {

    my $archivo = $cgi->param('editar');

    if (nombre_valido($archivo)) {

        $editar_archivo = $archivo;

        open(my $fh, "<:encoding(UTF-8)", "$RUTA/$archivo");

        $editar_contenido = join('', <$fh>);

        close($fh);
    }
}

print $cgi->header(
    -type => 'text/html',
    -charset => 'UTF-8'
);

print <<'HTML';

<!DOCTYPE html>

<html lang="es">

<head>

<meta charset="UTF-8">

<title>Gestión Manuales</title>

<style>

body{

    font-family:Arial;

    background:#f0f2f5;

    margin:40px;
}

h1{

    color:darkgreen;
}

.bloque{

    background:white;

    padding:20px;

    border-radius:10px;

    margin-top:20px;

    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

table{

    width:100%;

    border-collapse:collapse;
}

th,td{

    padding:12px;

    border-bottom:1px solid #ccc;
}

button{

    padding:8px 14px;

    border:none;

    border-radius:5px;

    cursor:pointer;

    color:white;

    font-weight:bold;
}

.editar{

    background:#0077cc;
}

.borrar{

    background:#cc3300;
}

.guardar{

    background:#28a745;
}

.subir{

    background:#6f42c1;
}

textarea{

    width:100%;

    height:300px;
}

.aviso{

    padding:12px;

    border-radius:8px;

    margin-bottom:20px;
}

.ok{

    background:#d4edda;
}

.error{

    background:#f8d7da;
}

</style>

</head>

<body>

<h1>Gestión de Manuales Técnicos</h1>

<div style="margin-bottom:20px;">

<a href="/cgi-bin/portal.pl">

<button class="editar">

Volver al portal

</button>

</a>

<a href="/cgi-bin/logout.pl">

<button class="borrar">

Cerrar sesión

</button>

</a>

</div>

HTML

if ($mensaje) {

    my $clase = $es_error ? "error" : "ok";

    print "<div class='aviso $clase'>$mensaje</div>";
}

print "

<div class='bloque'>

<h2>Archivos disponibles</h2>

<table>

<tr>

<th>Archivo</th>

<th>Acciones</th>

</tr>

";

foreach my $f (@archivos){

my $ef = esc($f);

print "

<tr>

<td>

<a href='/manuales/$ef'>$ef</a>

</td>

<td>

<form method='POST' style='display:inline;'>

<input type='hidden' name='editar' value='$ef'>

<button class='editar'>

Editar

</button>

</form>

<form method='POST' style='display:inline;' onsubmit='return confirm(\"¿Eliminar archivo?\")'>

<input type='hidden' name='borrar' value='$ef'>

<button class='borrar'>

Borrar

</button>

</form>

</td>

</tr>

";
}

print "

</table>

</div>

";

if ($editar_archivo) {

my $ea = esc($editar_archivo);

my $ec = esc($editar_contenido);

print "

<div class='bloque'>

<h2>Editando $ea</h2>

<form method='POST'>

<input type='hidden' name='archivo' value='$ea'>

<textarea name='contenido'>$ec</textarea>

<br><br>

<button type='submit' name='guardar' value='1' class='guardar'>

Guardar cambios

</button>

</form>

</div>

";
}

print <<'HTML';

<div class='bloque'>

<h2>Subir nuevo manual</h2>

<form method='POST' enctype='multipart/form-data'>

<input type='file' name='manual' accept='.txt' required>

<br><br>

<button type='submit' class='subir'>

Subir manual

</button>

</form>

<p>

Solo se permiten archivos .txt y máximo 2MB

</p>

</div>

</body>

</html>

HTML