#!/usr/bin/perl

use strict;
use warnings;

my $entrada = "/var/log/auth.log";
my $salida  = "/var/log/ecosalmantica_accesos.log";

my $ultimo = "";

open(my $fh, '<', $entrada)
    or die "No se pudo abrir auth.log\n";

seek($fh, 0, 2);

while (1) {

    while (my $line = <$fh>) {

        my $evento = "";

        if ($line =~ /Accepted .* for (\w+) from ([0-9.]+)/) {

            $evento =
                "[" . scalar(localtime) . "] SSH_OK usuario=$1 ip=$2\n";

        } elsif ($line =~ /Failed password for .* (\w+) from ([0-9.]+)/) {

            $evento =
                "[" . scalar(localtime) . "] SSH_FAIL usuario=$1 ip=$2\n";

        } elsif (
            $line =~ /session opened for user root/
        ) {

            $evento =
                "[" . scalar(localtime) . "] ROOT_SESSION\n";
        }

        next unless $evento;

        next if $evento eq $ultimo;

        $ultimo = $evento;

        open(my $log, '>>', $salida)
            or next;

        print $log $evento;

        close($log);
    }

    sleep 1;
}