#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use DBI;

binmode(STDOUT, ":encoding(UTF-8)");

my $q = CGI->new;

my $usuario_id = $q->param('usuario_id') || '';
my $codigo     = $q->param('codigo')     || '';
my $pass1      = $q->param('pass1')      || '';
my $pass2      = $q->param('pass2')      || '';

sub pagina {
    my ($titulo, $contenido) = @_;

    print $q->header(-type => 'text/html', -charset => 'UTF-8');
    print <<"HTML";
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>$titulo</title>
    <link rel="stylesheet" href="/css/estilos.css">
</head>
<body>
    <h1>EcoSalmántica</h1>

    <nav>
        <a href="/">Inicio</a>
        <a href="/login/">Login</a>
    </nav>

    <div class="bloque">
        $contenido
    </div>
</body>
</html>
HTML
    exit;
}

sub error {
    my ($msg) = @_;
    pagina("Error", <<"HTML");
<h2>Error</h2>
<p class="err">$msg</p>
<p><a href="/recuperar.html">Volver a recuperar contraseña</a></p>
HTML
}


error("Faltan datos del formulario.") unless $usuario_id && $codigo && $pass1 && $pass2;

error("Las contraseñas no coinciden.") unless $pass1 eq $pass2;

error("La contraseña es demasiado débil. Debe tener al menos 8 caracteres, una mayúscula, una minúscula y un número.")
    unless $pass1 =~ /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;


my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica;host=localhost",
    "admineco",
    "admineco123",
    { RaiseError => 1, mysql_enable_utf8 => 1 }
);


my $sth = $dbh->prepare(
    "SELECT cr.id, u.login
     FROM clave_recuperacion cr
     JOIN usuarios u ON u.id = cr.usuario_id
     WHERE cr.usuario_id = ?
       AND cr.clave = ?
       AND cr.expira > NOW()
       AND u.estado = 'activo'
     LIMIT 1"
);

$sth->execute($usuario_id, $codigo);

my $r = $sth->fetchrow_hashref;

unless ($r) {
    $dbh->disconnect;
    error("El código es incorrecto o ha caducado.");
}


my @chars = ('a'..'z', 'A'..'Z', '0'..'9');
my $salt_random = join('', map { $chars[int(rand(62))] } 1..16);
my $salt = '$y$j9T$' . $salt_random;
my $hash = crypt($pass1, $salt);


$dbh->do(
    "DELETE FROM cambios_password WHERE login = ?",
    undef,
    $r->{login}
);


$dbh->do(
    "INSERT INTO cambios_password (login, hash_nuevo)
     VALUES (?, ?)",
    undef,
    $r->{login},
    $hash
);


$dbh->do(
    "DELETE FROM clave_recuperacion WHERE id = ?",
    undef,
    $r->{id}
);

$dbh->disconnect;

pagina("Contraseña actualizada", <<"HTML");
<h2>Contraseña actualizada</h2>

<p class="ok">
La contraseña se ha actualizado correctamente. Se aplicará en el sistema en menos de un minuto.
</p>

<p>
Cuando el proceso automático la aplique, podrás iniciar sesión con la nueva contraseña en el panel, SSH, correo y SFTP.
</p>

<p><a href="/login/">Volver al login</a></p>
HTML