#!/usr/bin/perl
use strict;
use warnings;
use DBI;


my $db_name = "ecosalmantica";
my $db_user = "cron_limpieza";
my $db_pass = "limpieza123";

my $dbh = DBI->connect(
    "DBI:mysql:database=$db_name;host=localhost",
    $db_user,
    $db_pass,
    { RaiseError => 1, mysql_enable_utf8 => 1, AutoCommit => 1 }
);


my $deleted_keys = $dbh->do("DELETE FROM clave_recuperacion WHERE expira < NOW()");


my $query_condicion = "WHERE estado = 'pendiente' AND fecha_registro < DATE_SUB(NOW(), INTERVAL 5 MINUTE)";

my $pendientes = $dbh->selectcol_arrayref("SELECT login FROM usuarios $query_condicion");

if (@$pendientes) {
    foreach my $user_borrado (@$pendientes) {
        print "[".scalar(localtime)."] [LIMPIEZA] Borrando usuario caducado: $user_borrado\n";
    }


    $dbh->do("DELETE FROM tokens_verificacion WHERE usuario_id IN (SELECT id FROM usuarios $query_condicion)");


    $dbh->do("DELETE FROM usuarios $query_condicion");
}

$dbh->disconnect;