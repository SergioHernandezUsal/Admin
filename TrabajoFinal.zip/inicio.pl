#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use IO::Socket::INET;

binmode(STDOUT, ":encoding(UTF-8)");
my $cgi = CGI->new;


sub check {
    my ($port) = @_;
    my $socket = IO::Socket::INET->new(
        PeerAddr => 'localhost',
        PeerPort => $port,
        Proto    => 'tcp',
        Timeout  => 1
    );
    return $socket ? '<b style="color:green">OPERATIVO</b>' : '<b style="color:red">CAÍDO</b>';
}

my $s_web  = check(80);
my $s_ssl  = check(443);
my $s_ssh  = check(22);
my $s_sql  = check(3306);


print $cgi->header(-type => 'text/html', -charset => 'UTF-8');
print <<"HTML";
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ecosalmántica Smart City</title>
    <style>
        body { font-family: Arial; margin: 40px; background-color: #f5f5f5; }
        h1 { color: darkgreen; }
        nav { background-color: #333; padding: 15px; border-radius: 10px; }
        nav a { color: white; margin-right: 20px; text-decoration: none; font-weight: bold; }
        .bloque { background-color: white; padding: 20px; margin-top: 20px; border-radius: 10px; }
        ul { line-height: 25px; }
    </style>
</head>
<body>

    <h1>ECOSALMÁNTICA SMART CITY</h1>

    <nav>
        <a href="/cgi-bin/inicio.pl">Inicio</a>
        <a href="/login/">Login</a>
    </nav>

    <div class="bloque">
        <h2>Quiénes Somos</h2>
        <p>Ecosalmántica es una plataforma Smart City destinada a la gestión eficiente de servicios municipales.</p>
    </div>

    <div class="bloque">
        <h2>Nuestros Servicios</h2>
        <ul>
            <li>Portal ciudadano</li>
            <li>Webs personales</li>
            <li>Correo municipal</li>
            <li>Gestión técnica de sensores</li>
            <li>FTP/SFTP seguro</li>
        </ul>
    </div>

    <div class="bloque">
        <h2>Estado Servicios (Tiempo Real)</h2>
        <ul>
            <li>Apache Web: $s_web</li>
            <li>HTTPS SSL: $s_ssl</li>
            <li>SSH/SFTP: $s_ssh</li>
            <li>Base de Datos: $s_sql</li>
        </ul>
    </div>

</body>
</html>
HTML