#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use DBI;

my $cgi = CGI->new;
binmode(STDOUT, ":encoding(UTF-8)");

my $token = $cgi->param('token') || '';

sub respuesta {
    my ($titulo, $msg, $color) = @_;
    print $cgi->header(-type=>'text/html', -charset=>'UTF-8');
    print <<"HTML";
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>$titulo</title></head>
<body style="font-family:sans-serif; text-align:center; padding-top:50px; background:#f4f4f4;">
    <div style="background:white; display:inline-block; padding:30px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
        <h2 style="color:$color;">$titulo</h2>
        <p>$msg</p>
        <a href="/index.html" style="color:#007bff; text-decoration:none;">Volver al inicio</a>
    </div>
</body>
</html>
HTML
    exit;
}


my $dbh = DBI->connect("DBI:mysql:database=ecosalmantica;host=localhost",
                       "admineco", "admineco123",
                       { RaiseError => 1, mysql_enable_utf8 => 1 });


my $sth = $dbh->prepare("SELECT usuario_id FROM tokens_verificacion WHERE token = ? AND expira > NOW()");
$sth->execute($token);
my ($uid) = $sth->fetchrow_array;

if ($uid) {

    $dbh->do("UPDATE usuarios SET estado = 'confirmado' WHERE id = ?", undef, $uid);


    $dbh->do("DELETE FROM tokens_verificacion WHERE usuario_id = ?", undef, $uid);

    respuesta("¡Éxito!", "Código verificado. Tu cuenta de sistema se activará en menos de un minuto.", "green");
} else {
    respuesta("Error", "El código es incorrecto o ha caducado.", "red");
}

$dbh->disconnect;