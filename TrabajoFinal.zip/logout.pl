#!/usr/bin/perl
use strict;
use warnings;
use CGI;
use CGI::Session;

my $cgi     = CGI->new;
my $session = CGI::Session->new("driver:File", $cgi, {Directory => '/var/lib/cgi-sessions'});
$session->delete() if $session;

my $cookie = $cgi->cookie(
    -name    => 'CGISESSID',
    -value   => '',
    -expires => '-1d'
);

print $cgi->redirect(
    -uri    => '/',
    -cookie => $cookie
);

