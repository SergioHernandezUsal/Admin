#!/usr/bin/perl
use strict;
use warnings;
use DBI;
use Passwd::Unix;

die "Debe ejecutarse como root\n" if $> != 0;

my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica;host=localhost",
    "admineco",
    "admineco123",
    { RaiseError => 1, mysql_enable_utf8 => 1 }
);

sub login_valido {
    my ($login) = @_;
    return defined $login && $login =~ /^[a-z0-9._-]{3,20}$/;
}

sub hash_valido {
    my ($hash) = @_;
    return defined $hash && $hash =~ /^\$y\$/;
}

my $sth = $dbh->prepare("
    SELECT c.id, c.login, c.hash_nuevo
    FROM cambios_password c
    JOIN usuarios u ON u.login = c.login
    WHERE u.estado = 'activo'
");

$sth->execute();

while (my $c = $sth->fetchrow_hashref) {

    unless (
        login_valido($c->{login}) &&
        hash_valido($c->{hash_nuevo})
    ) {
        print "[ERROR] Cambio de contraseña inválido id=$c->{id}\n";

        $dbh->do(
            "DELETE FROM cambios_password WHERE id = ?",
            undef,
            $c->{id}
        );

        next;
    }

    my $pu      = Passwd::Unix->new();
    my @usuario = $pu->user($c->{login});

    if (@usuario) {

        $pu->user(
            $c->{login},
            $c->{hash_nuevo},
            $usuario[1],
            $usuario[2],
            $usuario[3],
            $usuario[4],
            $usuario[5]
        );

        print "[PASSWORD] Contraseña actualizada para $c->{login}\n";

    } else {
        print "[ERROR] Usuario $c->{login} no encontrado en el sistema\n";
    }

    $dbh->do(
        "DELETE FROM cambios_password WHERE id = ?",
        undef,
        $c->{id}
    );
}

$dbh->disconnect;