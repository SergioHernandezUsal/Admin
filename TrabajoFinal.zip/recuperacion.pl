#!/usr/bin/perl
use strict;
use warnings;
use utf8;
use CGI;
use DBI;
use MIME::Lite;

binmode(STDOUT, ":encoding(UTF-8)");

my $q = CGI->new;

my $login = $q->param('login') || '';
my $email = $q->param('email') || '';

sub pagina {

    my ($titulo, $contenido) = @_;

    print $q->header(
        -type    => 'text/html',
        -charset => 'UTF-8'
    );

    print <<"HTML";
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>$titulo</title>
    <link rel="stylesheet" href="/css/estilos.css">
</head>
<body>

<h1>EcoSalmántica</h1>

<nav>
    <a href="/">Inicio</a>
    <a href="/login/">Login</a>
</nav>

<div class="bloque">
$contenido
</div>

</body>
</html>
HTML

    exit;
}



unless ($login && $email) {

    print $q->redirect('/recuperar.html');
    exit;
}



my $dbh = DBI->connect(
    "DBI:mysql:database=ecosalmantica;host=localhost",
    "admineco",
    "admineco123",
    {
        RaiseError        => 1,
        mysql_enable_utf8 => 1
    }
);



my $sth = $dbh->prepare(
    "SELECT id, nombre, email
     FROM usuarios
     WHERE login = ?
     AND email = ?
     AND estado = 'activo'
     LIMIT 1"
);

$sth->execute($login, $email);

my $u = $sth->fetchrow_hashref;



unless ($u) {

    $dbh->disconnect;

    pagina("Recuperación", <<"HTML");
<h2>Recuperación solicitada</h2>

<p>
Si los datos son correctos,
se habrá enviado un código.
</p>

<p>
<a href="/login/">Volver</a>
</p>
HTML
}



my $codigo = 10000 + int(rand(90000));



$dbh->do(
    "DELETE FROM clave_recuperacion
     WHERE usuario_id = ?",
    undef,
    $u->{id}
);



$dbh->do(
    "INSERT INTO clave_recuperacion
     (usuario_id, clave, expira)
     VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))",
    undef,
    $u->{id},
    $codigo
);


eval {

    my $msg = MIME::Lite->new(
        From    => 'carloscuadrado0606@gmail.com',
        To      => $u->{email},
        Subject => 'Recuperación EcoSalmantica',
        Data    => <<"MAIL"
Hola $u->{nombre},

Tu código de recuperación es:

$codigo

Caduca en 15 minutos.

EcoSalmantica
MAIL
    );

    $msg->send;
};

if ($@) {

    warn "Error enviando correo: $@";

    $dbh->disconnect;

    pagina("Error", <<"HTML");
<h2>Error</h2>

<p class="err">
No se pudo enviar el correo.
</p>

<p>
<a href="/login/">Volver</a>
</p>
HTML
}

$dbh->disconnect;



my $uid = $q->escapeHTML($u->{id});

pagina("Recuperación", <<"HTML");
<h2>Recuperación de contraseña</h2>

<p class="ok">
Se ha enviado un código al correo asociado.
</p>

<p>
Caduca en 15 minutos.
</p>

<form method="post"
      action="/cgi-bin/comprobar_recuperacion.pl">

<input type="hidden"
       name="usuario_id"
       value="$uid">

<label>Código:</label>
<input type="text"
       name="codigo"
       required>

<label>Nueva contraseña:</label>
<input type="password"
       name="pass1"
       required>

<label>Repetir contraseña:</label>
<input type="password"
       name="pass2"
       required>

<button type="submit">
Cambiar contraseña
</button>

</form>

<p>
<a href="/login/">Volver</a>
</p>
HTML